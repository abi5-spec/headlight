"""Threadlight web server. Run with:  python server.py   (then open http://localhost:8000)"""
import json
import mimetypes
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from threadlight import llm
from threadlight.api import ROUTES

STATIC_DIR = (Path(__file__).parent / "static").resolve()
MAX_BODY = 10_000


class Handler(BaseHTTPRequestHandler):
    server_version = "Threadlight/1.0"

    def _send(self, status, body, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status, payload):
        self._send(status, json.dumps(payload).encode("utf-8"), "application/json; charset=utf-8")

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/health":
            return self._json(200, {"status": "ok", "claude": llm.available()})
        relative = "index.html" if path in ("", "/") else path.lstrip("/")
        target = (STATIC_DIR / relative).resolve()
        if STATIC_DIR not in target.parents or not target.is_file():
            return self._json(404, {"error": "Not found"})
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in ("application/javascript",):
            content_type += "; charset=utf-8"
        self._send(200, target.read_bytes(), content_type)

    def do_POST(self):
        route = ROUTES.get(urlparse(self.path).path)
        if route is None:
            return self._json(404, {"error": "Not found"})
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return self._json(400, {"error": "Bad Content-Length"})
        if length > MAX_BODY:
            return self._json(413, {"error": "Request too large"})
        try:
            payload = json.loads(self.rfile.read(length) or b"{}")
            if not isinstance(payload, dict):
                raise ValueError("Body must be a JSON object.")
            self._json(200, route(payload))
        except ValueError as error:  # includes json.JSONDecodeError
            self._json(400, {"error": str(error)})
        except Exception:
            self._json(500, {"error": "Something went wrong on our side."})


def main():
    port = int(os.environ.get("PORT", "8000"))
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    mode = "Claude API" if llm.available() else "built-in rules"
    print("Threadlight running on http://localhost:%d  (challenge mode: %s)" % (port, mode))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()

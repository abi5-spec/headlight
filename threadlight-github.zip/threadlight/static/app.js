(function () {
  "use strict";

  var state = { topicId: null, shown: 0, confidence: 0.2 };

  function $(sel) { return document.querySelector(sel); }
  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function post(url, body) {
    return fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    }).then(function (res) {
      return res.json().then(function (data) {
        if (!res.ok) throw new Error(data.error || "Request failed");
        return data;
      });
    });
  }
  function setStep(n) {
    document.querySelectorAll("#steps li").forEach(function (li) {
      li.classList.toggle("on", Number(li.dataset.step) <= n);
    });
  }
  function reveal(id) {
    var node = $(id);
    node.hidden = false;
    return node;
  }
  function showConfidence(value) {
    state.confidence = value;
    var pct = Math.round(value * 100);
    $("#conf-value").textContent = pct + "%";
    $("#conf-bar").style.width = pct + "%";
  }

  function renderChallenge(c) {
    var box = $("#challenge");
    box.replaceChildren();
    box.appendChild(el("p", "eyebrow", "Your challenge"));
    box.appendChild(el("p", "goal", c.goal));

    var q = el("div", "question");
    q.appendChild(el("strong", null, "Threadlight asks: "));
    q.appendChild(document.createTextNode(c.clarifying_question));
    box.appendChild(q);

    var list = el("ul", "measures");
    c.measures.forEach(function (m) { list.appendChild(el("li", null, m)); });
    box.appendChild(list);

    if (c.formula) {
      var f = el("div", "formula");
      f.appendChild(el("div", "expr", c.formula.expr));
      f.appendChild(el("div", "cap", c.formula.caption));
      box.appendChild(f);
    }
    if (c.stretch) box.appendChild(el("p", null, "Stretch goal: " + c.stretch));
    if (c.safety) box.appendChild(el("p", "note", "Safety: " + c.safety));
    if (c.concepts && c.concepts.length) {
      var chips = el("div", "chips");
      c.concepts.forEach(function (x) { chips.appendChild(el("span", "chip", x)); });
      box.appendChild(chips);
    }
  }

  function renderMatches(matches) {
    var box = $("#matches");
    box.replaceChildren();
    matches.forEach(function (m, i) {
      var card = el("div", "match");
      card.appendChild(el("span", "kind", m.kind));
      card.appendChild(el("h3", null, m.title));
      card.appendChild(el("p", null, m.summary));
      card.appendChild(el("div", "score", m.match.toFixed(2) + " match"));
      var bar = el("div", "bar");
      var fill = el("div");
      bar.appendChild(fill);
      card.appendChild(bar);
      box.appendChild(card);
      setTimeout(function () { fill.style.width = Math.round(m.match * 100) + "%"; }, 150 + i * 150);
    });
  }

  function addHint(h) {
    var box = el("div", "hint");
    box.appendChild(el("div", "label", "Hint " + h.level + " · " + h.label));
    box.appendChild(el("p", null, h.text));
    $("#hints").appendChild(box);
  }

  $("#spot-form").addEventListener("submit", function (event) {
    event.preventDefault();
    var button = $("#go"), error = $("#error");
    error.hidden = true;
    button.disabled = true;
    button.textContent = "Building…";
    post("/api/frame", { text: $("#problem").value, level: $("#level").value })
      .then(function (data) {
        state.topicId = data.challenge.topic_id;
        state.shown = 0;
        $("#hints").replaceChildren();
        showConfidence(data.confidence);
        renderChallenge(data.challenge);
        renderMatches(data.matches);
        reveal("#frame"); reveal("#connect"); reveal("#guide");
        setStep(4);
        $("#frame").scrollIntoView({ behavior: "smooth" });
      })
      .catch(function (err) {
        error.textContent = err.message;
        error.hidden = false;
      })
      .then(function () {
        button.disabled = false;
        button.textContent = "Build my challenge";
      });
  });

  $("#stuck").addEventListener("click", function () {
    post("/api/hint", { topic_id: state.topicId, stuck: state.shown })
      .then(function (hint) {
        if (state.shown < 3) { addHint(hint); }
        state.shown += 1;
        return post("/api/confidence", { confidence: state.confidence, success: false });
      })
      .then(function (r) { showConfidence(r.confidence); })
      .catch(function (err) { alert(err.message); });
  });

  $("#solved").addEventListener("click", function () {
    post("/api/confidence", { confidence: state.confidence, success: true })
      .then(function (r) { showConfidence(r.confidence); })
      .catch(function (err) { alert(err.message); });
  });
})();

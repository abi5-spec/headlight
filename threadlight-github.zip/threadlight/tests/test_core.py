import json
import sys
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from server import Handler  # noqa: E402
from threadlight import api, hints, llm, matching  # noqa: E402
from threadlight.challenge import detect_topic, frame, topic_by_id  # noqa: E402


class MatchingTests(unittest.TestCase):
    def test_stemming_groups_word_forms(self):
        self.assertEqual(matching.stem("floods"), matching.stem("flooded"))
        self.assertEqual(matching.stem("wasted"), matching.stem("waste"))

    def test_cosine_identical_and_disjoint(self):
        idf = {"a": 1.0, "b": 1.0}
        v = matching.vectorize(["a"], idf)
        self.assertAlmostEqual(matching.cosine(v, v), 1.0)
        self.assertEqual(matching.cosine(v, matching.vectorize(["b"], idf)), 0.0)
        self.assertEqual(matching.cosine({}, v), 0.0)

    def test_level_fit(self):
        self.assertEqual(matching.level_fit(1, 1), 1.0)
        self.assertEqual(matching.level_fit(1, 2), 0.5)
        self.assertEqual(matching.level_fit(1, 3), 0.0)

    def test_flood_problem_ranks_flood_resources_first(self):
        top = matching.rank("The road near my school floods every time it rains.", 1,
                            topic_by_id("flooding")["keywords"])
        self.assertEqual(len(top), 3)
        self.assertIn(top[0]["id"], {"hydrology-basics", "build-rain-gauge"})
        scores = [m["match"] for m in top]
        self.assertEqual(scores, sorted(scores, reverse=True))
        self.assertTrue(all(0.0 <= s <= 1.0 for s in scores))


class ChallengeTests(unittest.TestCase):
    def test_topic_detection(self):
        cases = {
            "The road near my school floods every time it rains.": "flooding",
            "We have power cuts every evening and homework is hard.": "power",
            "Fruit at our market spoils before we can sell it.": "food_waste",
            "The river water near us looks dirty and cloudy.": "clean_water",
            "There is plastic litter all over the playground.": "waste",
            "My classmates seem tired in the morning.": "general",
        }
        for text, expected in cases.items():
            self.assertEqual(detect_topic(text)["id"], expected, text)

    def test_frame_has_required_fields(self):
        result = frame("The road floods when it rains", "advanced", use_llm=False)
        for key in ("goal", "measures", "formula", "clarifying_question", "topic_id"):
            self.assertIn(key, result)
        self.assertEqual(result["source"], "rules")
        self.assertIsNotNone(result["stretch"])
        self.assertIsNone(frame("The road floods when it rains", "beginner", use_llm=False)["stretch"])


class HintTests(unittest.TestCase):
    def test_hints_escalate_and_cap(self):
        topic = topic_by_id("flooding")
        levels = [hints.hint_for(topic, n)["level"] for n in (0, 1, 2, 3, 10)]
        self.assertEqual(levels, [1, 2, 3, 3, 3])
        self.assertTrue(hints.hint_for(topic, 2)["is_last"])
        self.assertEqual(hints.hint_for(topic, -5)["level"], 1)

    def test_confidence_moves_toward_outcome_and_stays_bounded(self):
        self.assertGreater(hints.update_confidence(0.2, True), 0.2)
        self.assertLess(hints.update_confidence(0.8, False), 0.8)
        self.assertLessEqual(hints.update_confidence(1.0, True), 1.0)
        self.assertGreaterEqual(hints.update_confidence(0.0, False), 0.0)


class LlmParseTests(unittest.TestCase):
    def test_parses_fenced_json(self):
        raw = '```json\n{"goal":"g","measures":["a","b","c"],"clarifying_question":"q?","concepts":["x"]}\n```'
        out = llm._parse(raw)
        self.assertEqual(out["goal"], "g")
        self.assertEqual(len(out["measures"]), 3)

    def test_rejects_bad_shape(self):
        with self.assertRaises(Exception):
            llm._parse('{"goal":"g","measures":"nope","clarifying_question":"q"}')


class ApiTests(unittest.TestCase):
    def test_validation(self):
        with self.assertRaises(ValueError):
            api.handle_frame({"text": "hi"})
        with self.assertRaises(ValueError):
            api.handle_frame({"text": "x" * 2000})
        with self.assertRaises(ValueError):
            api.handle_frame({"text": "The road floods a lot", "level": "expert"})
        with self.assertRaises(ValueError):
            api.handle_hint({"topic_id": "nope"})


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.base = "http://127.0.0.1:%d" % cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()

    def post(self, path, body):
        req = urllib.request.Request(self.base + path, data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req) as res:
                return res.status, json.load(res)
        except urllib.error.HTTPError as e:
            return e.code, json.load(e)

    def test_health_and_index(self):
        with urllib.request.urlopen(self.base + "/api/health") as res:
            self.assertEqual(json.load(res)["status"], "ok")
        with urllib.request.urlopen(self.base + "/") as res:
            self.assertIn(b"Threadlight", res.read())

    def test_path_traversal_blocked(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(self.base + "/../server.py")
        self.assertEqual(ctx.exception.code, 404)

    def test_full_flow(self):
        status, data = self.post("/api/frame", {"text": "The road near my school floods every time it rains.", "level": "beginner"})
        self.assertEqual(status, 200)
        self.assertEqual(data["challenge"]["topic_id"], "flooding")
        self.assertEqual(len(data["matches"]), 3)
        status, hint = self.post("/api/hint", {"topic_id": "flooding", "stuck": 0})
        self.assertEqual((status, hint["level"]), (200, 1))
        status, conf = self.post("/api/confidence", {"confidence": 0.2, "success": True})
        self.assertGreater(conf["confidence"], 0.2)

    def test_bad_requests(self):
        self.assertEqual(self.post("/api/frame", {"text": ""})[0], 400)
        self.assertEqual(self.post("/api/nope", {})[0], 404)
        req = urllib.request.Request(self.base + "/api/frame", data=b"not json", method="POST")
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req)
        self.assertEqual(ctx.exception.code, 400)


if __name__ == "__main__":
    unittest.main()

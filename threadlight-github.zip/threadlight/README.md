# Threadlight

**Where curiosity finds its thread.**

[![CI](https://github.com/YOUR-USERNAME/threadlight/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR-USERNAME/threadlight/actions)

Threadlight is an AI companion that helps students turn real problems in their community into guided STEM challenges. A student describes something they noticed, such as a school road that floods when it rains, and Threadlight walks them from curiosity to a working solution. Built for the stem2connest AI hackathon.

## How it works

| Step | What happens |
|---|---|
| **1. Spot it** | The student describes a problem in plain language. |
| **2. Frame it** | Threadlight turns it into a measurable challenge, with a clarifying question, things to measure, and a key formula. |
| **3. Connect it** | Lessons, guides, and mentors are ranked for the problem and the student's level. |
| **4. Guide it** | Hints escalate only when the student says they're stuck (nudge, direction, clue) and never give the answer. A confidence meter adapts as they progress. |

### The math

**Matching.** Each resource is scored against the problem with TF-IDF cosine similarity blended with a difficulty fit:

```
score(p, r) = α · cos(e_p, e_r) + (1 − α) · fit(level_p, level_r)        α = 0.7
fit = 1 − |level_p − level_r| / 2
```

**Confidence.** After each step the confidence estimate moves toward the outcome:

```
c(t+1) = c(t) + η · (y(t) − c(t))        η = 0.3, y = 1 on success, 0 when stuck
```

## Quick start

Requires **Python 3.9 or newer**. There is nothing to install.

```bash
git clone https://github.com/YOUR-USERNAME/threadlight.git
cd threadlight
python server.py
```

Open **http://localhost:8000**.

### Optional: let Claude write the challenge

By default Threadlight builds challenges from built-in rules. To have Claude write the goal, measurements, and clarifying question, set an API key before starting the server:

```bash
export ANTHROPIC_API_KEY=your-key-here      # Windows PowerShell: $env:ANTHROPIC_API_KEY="your-key-here"
python server.py
```

If the API call fails for any reason, Threadlight falls back to the built-in rules automatically. Never commit your key; `.env` is already in `.gitignore`.

## Run the tests

```bash
python -m unittest discover -s tests -v
```

## API

| Method | Path | Body | Returns |
|---|---|---|---|
| `GET` | `/api/health` | | `{"status": "ok", "claude": false}` |
| `POST` | `/api/frame` | `{"text": "...", "level": "beginner"}` | the challenge, the top 3 matches, and starting confidence |
| `POST` | `/api/hint` | `{"topic_id": "flooding", "stuck": 0}` | the next hint in the ladder |
| `POST` | `/api/confidence` | `{"confidence": 0.2, "success": true}` | the updated confidence |

## Project structure

```
threadlight/
├── server.py               # HTTP server (standard library only)
├── threadlight/
│   ├── api.py              # request handlers and validation
│   ├── challenge.py        # topic detection and challenge framing
│   ├── matching.py         # TF-IDF matching engine
│   ├── hints.py            # hint ladder and confidence update
│   ├── llm.py              # optional Claude integration
│   └── data/               # topics.json and resources.json
├── static/                 # index.html, style.css, app.js
├── tests/test_core.py
└── .github/workflows/ci.yml
```

## Adding your own content

- **New topic:** add an entry to `threadlight/data/topics.json` with keywords, measures, a formula, and three hints.
- **New lesson or mentor:** add an entry to `threadlight/data/resources.json`. Matching picks it up automatically.

## Limitations

- The built-in topic detector recognizes five themes (flooding, power cuts, food spoilage, water quality, waste) plus a general fallback.
- Mentors and lessons in `resources.json` are sample entries, not real people or links.
- This is a hackathon prototype and has no accounts or saved progress.

## What's next

- Pilot with a real classroom
- Multilingual support, including local languages
- A neural embedding model for matching
- Let students share finished projects

## License

MIT. See [LICENSE](LICENSE).

"""Optional Claude integration (standard library only).

Set ANTHROPIC_API_KEY to let Claude write the challenge goal, measurements, and
clarifying question. Without a key Threadlight uses its built-in rules.
"""
import json
import os
import re
import urllib.request

API_URL = "https://api.anthropic.com/v1/messages"
SYSTEM = (
    "You help students turn real community problems into STEM challenges. "
    "Reply with a single JSON object and nothing else, using exactly these keys: "
    '"goal" (string, one measurable goal), '
    '"measures" (array of exactly 3 short strings the student can measure or calculate), '
    '"clarifying_question" (string, one question to learn more about the problem), '
    '"concepts" (array of up to 3 STEM concepts). '
    "Never give the solution. Keep the language simple and safe for students."
)


def available():
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def _parse(text):
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
    data = json.loads(text)
    goal = data["goal"]
    measures = data["measures"]
    question = data["clarifying_question"]
    concepts = data.get("concepts", [])
    if not isinstance(goal, str) or not isinstance(question, str):
        raise ValueError("bad types")
    if not (isinstance(measures, list) and measures and all(isinstance(m, str) for m in measures)):
        raise ValueError("bad measures")
    return {
        "goal": goal[:160],
        "measures": [m[:120] for m in measures[:3]],
        "clarifying_question": question[:200],
        "concepts": [c for c in concepts if isinstance(c, str)][:3],
    }


def frame_with_llm(problem, level_name, timeout=20):
    body = {
        "model": os.environ.get("THREADLIGHT_MODEL", "claude-sonnet-5-5"),
        "max_tokens": 600,
        "system": SYSTEM,
        "messages": [{"role": "user", "content": "Student level: %s\nProblem: %s" % (level_name, problem)}],
    }
    request = urllib.request.Request(
        API_URL,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "content-type": "application/json",
            "x-api-key": os.environ["ANTHROPIC_API_KEY"],
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.load(response)
    text = "".join(b.get("text", "") for b in payload.get("content", []) if b.get("type") == "text")
    return _parse(text)

"""Turns a student's observation into a structured STEM challenge."""
import json

from . import llm
from .matching import DATA_DIR, tokenize

_TOPICS = None


def load_topics():
    global _TOPICS
    if _TOPICS is None:
        with open(DATA_DIR / "topics.json", encoding="utf-8") as f:
            _TOPICS = json.load(f)
    return _TOPICS


def topic_by_id(topic_id):
    for topic in load_topics():
        if topic["id"] == topic_id:
            return topic
    raise ValueError("Unknown topic: %s" % topic_id)


def detect_topic(text):
    """Pick the topic whose keywords overlap the text most (ties go to the first topic)."""
    words = set(tokenize(text))
    best, best_hits = topic_by_id("general"), 0
    for topic in load_topics():
        hits = len(words & set(tokenize(" ".join(topic["keywords"]))))
        if hits > best_hits:
            best, best_hits = topic, hits
    return best


def frame(text, level_name="beginner", use_llm=True):
    """Build a challenge. Uses the Claude API when ANTHROPIC_API_KEY is set; otherwise rules."""
    topic = detect_topic(text)
    challenge = {
        "topic_id": topic["id"],
        "problem": text.strip()[:200],
        "goal": topic["goal"],
        "measures": list(topic["measures"]),
        "concepts": list(topic["concepts"]),
        "formula": dict(topic["formula"]),
        "clarifying_question": topic["clarifying_question"],
        "safety": topic["safety"],
        "stretch": topic["stretch"] if level_name == "advanced" else None,
        "source": "rules",
    }
    if use_llm and llm.available():
        try:
            extra = llm.frame_with_llm(text, level_name)
            challenge.update(extra)
            challenge["source"] = "claude"
        except Exception:
            pass  # fall back to the rule-based challenge
    return challenge

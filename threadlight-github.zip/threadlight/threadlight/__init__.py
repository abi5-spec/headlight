"""Threadlight: an AI companion that turns community problems into guided STEM challenges."""

__version__ = "1.0.0"

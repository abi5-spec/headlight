"""Matching engine: ranks lessons, guides, and mentors for a student's problem.

score(p, r) = alpha * cos(e_p, e_r) + (1 - alpha) * fit(level_p, level_r)

Embeddings e_p and e_r are TF-IDF vectors, so the engine needs no external
libraries. You can swap `vectorize` for a neural embedding model later.
"""
import json
import math
import re
from collections import Counter
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"
LEVELS = {"beginner": 1, "intermediate": 2, "advanced": 3}
DEFAULT_ALPHA = 0.7

_WORD = re.compile(r"[a-z]+")
_STOP = {
    "the", "and", "for", "are", "but", "not", "you", "all", "any", "can", "had", "her", "was", "one",
    "our", "out", "has", "his", "how", "its", "may", "new", "now", "old", "see", "two", "who", "did",
    "too", "use", "that", "with", "have", "this", "will", "your", "from", "they", "been", "were",
    "what", "when", "which", "there", "their", "every", "time", "each", "than", "then", "them",
    "some", "into", "just", "more", "most", "over", "very", "does", "dont", "near", "always",
    "again", "about", "after", "because", "where", "while", "would", "could", "should", "keeps",
    "keep", "gets", "get", "make", "made", "like", "also", "still", "much", "many",
}


def stem(word):
    """A tiny stemmer: floods/flooded/flooding -> flood, waste/wasted -> wast."""
    for suffix in ("ing", "ed", "s"):
        if word.endswith(suffix) and len(word) - len(suffix) >= 3:
            word = word[: -len(suffix)]
            break
    if word.endswith("e") and len(word) > 3:
        word = word[:-1]
    return word


def tokenize(text):
    return [stem(w) for w in _WORD.findall(text.lower()) if len(w) > 2 and w not in _STOP]


def build_idf(docs):
    n = len(docs)
    df = Counter()
    for tokens in docs:
        df.update(set(tokens))
    return {t: math.log((1 + n) / (1 + c)) + 1 for t, c in df.items()}


def vectorize(tokens, idf):
    tf = Counter(tokens)
    return {t: tf[t] * idf[t] for t in tf if t in idf}


def cosine(a, b):
    if not a or not b:
        return 0.0
    dot = sum(v * b.get(t, 0.0) for t, v in a.items())
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    return dot / (na * nb) if na and nb else 0.0


def level_fit(student_level, resource_level):
    """1.0 when levels match, 0.5 when one apart, 0.0 when two apart."""
    return 1.0 - abs(student_level - resource_level) / 2.0


def score(cos_sim, fit, alpha=DEFAULT_ALPHA):
    return alpha * cos_sim + (1 - alpha) * fit


def load_resources():
    with open(DATA_DIR / "resources.json", encoding="utf-8") as f:
        return json.load(f)


def rank(problem_text, level, topic_keywords=(), top_k=3, alpha=DEFAULT_ALPHA):
    """Return the top_k resources for a problem, each with a 0-1 `match` score."""
    resources = load_resources()
    docs = [tokenize(f"{r['title']} {r['summary']} {r['tags']}") for r in resources]
    idf = build_idf(docs)
    query = vectorize(tokenize(problem_text) + tokenize(" ".join(topic_keywords)), idf)

    ranked = []
    for resource, tokens in zip(resources, docs):
        cos_sim = cosine(query, vectorize(tokens, idf))
        s = score(cos_sim, level_fit(level, resource["level"]), alpha)
        ranked.append({
            "id": resource["id"],
            "title": resource["title"],
            "kind": resource["kind"],
            "summary": resource["summary"],
            "match": round(max(0.0, min(1.0, s)), 2),
        })
    ranked.sort(key=lambda r: (-r["match"], r["title"]))
    return ranked[:top_k]

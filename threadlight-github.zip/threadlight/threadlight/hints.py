"""Escalating hints and the adaptive confidence estimate.

c(t+1) = c(t) + eta * (y(t) - c(t)),  where y(t) is 1 on success and 0 when stuck.
The ladder never reveals a final answer: nudge -> direction -> clue.
"""
LABELS = ["Nudge", "Direction", "Clue"]
DEFAULT_ETA = 0.3
START_CONFIDENCE = 0.2


def hint_for(topic, stuck):
    index = min(max(int(stuck), 0), len(topic["hints"]) - 1)
    return {
        "level": index + 1,
        "label": LABELS[index],
        "text": topic["hints"][index],
        "is_last": index == len(topic["hints"]) - 1,
    }


def update_confidence(confidence, success, eta=DEFAULT_ETA):
    y = 1.0 if success else 0.0
    updated = confidence + eta * (y - confidence)
    return round(max(0.0, min(1.0, updated)), 3)

"""Request handlers, kept separate from HTTP so they are easy to test."""
from . import challenge as challenge_mod
from . import hints
from .matching import LEVELS, rank

MIN_TEXT, MAX_TEXT = 8, 1000


def handle_frame(payload):
    text = str(payload.get("text", "")).strip()
    if len(text) < MIN_TEXT:
        raise ValueError("Please describe the problem in a sentence or two.")
    if len(text) > MAX_TEXT:
        raise ValueError("Please keep the description under %d characters." % MAX_TEXT)
    level_name = str(payload.get("level", "beginner")).lower()
    if level_name not in LEVELS:
        raise ValueError("Level must be beginner, intermediate, or advanced.")

    challenge = challenge_mod.frame(text, level_name)
    topic = challenge_mod.topic_by_id(challenge["topic_id"])
    matches = rank(text, LEVELS[level_name], topic["keywords"])
    return {"challenge": challenge, "matches": matches, "confidence": hints.START_CONFIDENCE}


def handle_hint(payload):
    topic = challenge_mod.topic_by_id(str(payload.get("topic_id", "")))
    try:
        stuck = int(payload.get("stuck", 0))
    except (TypeError, ValueError):
        raise ValueError("stuck must be a number.")
    return hints.hint_for(topic, stuck)


def handle_confidence(payload):
    try:
        current = float(payload.get("confidence", hints.START_CONFIDENCE))
    except (TypeError, ValueError):
        raise ValueError("confidence must be a number.")
    current = max(0.0, min(1.0, current))
    return {"confidence": hints.update_confidence(current, bool(payload.get("success")))}


ROUTES = {
    "/api/frame": handle_frame,
    "/api/hint": handle_hint,
    "/api/confidence": handle_confidence,
}
